<?php
//koneksi ke database
$conn= mysqli_connect("localhost","root","","sistempenilaian");


function query($query){
	global $conn;
	$result=mysqli_query($conn,$query);
	$rows=[];
	while($row=mysqli_fetch_assoc($result)){
		$rows[]=$row;
	}
	return $rows; 
}

function tambah($data){
	global $conn;

	$nisn=htmlspecialchars($data["nisn"]);
	$nama=htmlspecialchars($data["nama"]);
	$nama_panggilan= htmlspecialchars($data["nama_panggilan"]);
	$jk=htmlspecialchars($data["jk"]);
	$tempat_lahir=htmlspecialchars($data["tempat_lahir"]);
	$tanggal_lahir=htmlspecialchars($data["tanggal_lahir"]);
	$alamat=htmlspecialchars($data["alamat"]);

	//upload Gambar
	$gambar= upload();
	if (!$gambar) {
		return false;
	} 

	$result = mysqli_query($conn, "SELECT nisn FROM siswa WHERE nisn = '$nisn'");


	if(mysqli_fetch_assoc($result)){
		echo 	"<script>
					alert('Data sudah ada');
				</script>";
		return false;		
	}

	$query="INSERT INTO siswa
			VALUES 
			('', '$nisn', '$nama' ,'$nama_panggilan','$jk','$tempat_lahir','$tanggal_lahir','$alamat', '$gambar')

			";
	
	mysqli_query($conn,$query);

	return mysqli_affected_rows($conn);
}

function upload(){

	//ambil data file
	$namaFile=$_FILES['gambar']['name']; //nama gambar
	$ukuranFile=$_FILES['gambar']['size']; //ukuran gambar
	$error= $_FILES['gambar']['error'];//ada gambar yang diupload atau tidak (error)
	$tmpName= $_FILES['gambar']['tmp_name'];//tempat penyimpanan sementara

	//cek apakah tidak ada gambar yang diupload
	if( $error == 4 ){
		echo 	"<script>
					alert('Silahkan Masukkan Gambar!')
				</script>";
		return false;
	}

	//cek yang diupload adalah gambar
	$ekstensiGambarValid= ['jpg','jpeg','png']; //ekstensi gambar yang boleh masuk  
	$ekstensiGambar = explode('.', $namaFile); //ekstensi file dari gbr yg diupload
	$ekstensiGambar = strtolower (end($ekstensiGambar)); //ambil ekstensi gambar yg akan masuk yg paling akhir

	//mencari apakah ada ekstensi gambar yang dimasukkan(yang dimasukkan berupa gambar atau tidak) string di dalam array
	 if( !in_array( $ekstensiGambar, $ekstensiGambarValid)){
		echo 	"<script>
					alert('Pilih gambar dengan benar!')
				</script>";
		return false;
	 }

	 //cek jika ukurannya terlalu besar

	 if( $ukuranFile > 1000000){
		echo 	"<script>
					alert('Ukuran gambar teralu besar')
				</script>";
		return false;	 	
	 }

	 //lolos pengecekan, gambar siap diupload
	 //generate nama gambar baru
	 $namaFileBaru = uniqid();//string angka random untuk nama baru
	 $namaFileBaru .= '.';
	 $namaFileBaru .= $ekstensiGambar; 

	 move_uploaded_file($tmpName, 'img/'. $namaFileBaru);

	 return $namaFileBaru;

}

function hapussiswa($id_siswa){
	global $conn;
	mysqli_query($conn, "DELETE FROM siswa WHERE id_siswa='$id_siswa'");


	return mysqli_affected_rows($conn);
}

function ubahsiswa($data){
	global $conn;

	$id_siswa = $data["id_siswa"];
	$nisn=htmlspecialchars($data["nisn"]);
	$nama=htmlspecialchars($data["nama"]);
	$nama_panggilan= htmlspecialchars($data["nama_panggilan"]);
	$jk=htmlspecialchars($data["jk"]);
	$tempat_lahir=htmlspecialchars($data["tempat_lahir"]);
	$tanggal_lahir=htmlspecialchars($data["tanggal_lahir"]);
	$alamat=htmlspecialchars($data["alamat"]);

	$gambarLama=htmlspecialchars($data["gambarLama"]);

	//cek apakah user pilih gambar baru atau tidak
	if($_FILES['gambar']['error'] === 4 ){
		$gambar = $gambarLama;
	}else{
			$gambar = upload();
	}


	$query="UPDATE siswa SET 
			nisn='$nisn',
			nama='$nama',
			nama_panggilan='$nama_panggilan',
			jk='$jk',
			tempat_lahir='$tempat_lahir',
			tanggal_lahir='$tanggal_lahir',
			alamat='$alamat',
			gambar='$gambar'
			WHERE id_siswa='$id_siswa'
			";
			
	mysqli_query($conn,$query);

	return mysqli_affected_rows($conn);
}

function cari($keyword){
	$query="SELECT * FROM siswa
			WHERE
			nisn LIKE '%$keyword%' OR
			nama LIKE '%$keyword%' OR
			nama_panggilan LIKE '%$keyword%' OR
			jk LIKE '%$keyword%'

			";


	return query($query);
}

function registrasi($data){
	global $conn;

	$username = strtolower(stripcslashes($data["username"] ) );
	$password = mysqli_real_escape_string( $conn, $data["password"] );
	$password2 = mysqli_real_escape_string( $conn, $data["password2"] );

	//cek username sudah ada atau belum
	$result = mysqli_query($conn, "SELECT username FROM user WHERE username = '$username'");

	if (mysqli_fetch_assoc($result)) {
		echo "<script>
				alert('Username Sudah Terdaftar');
		</script>";
		return false;
	}

	//cek konfirmasi password
	if ($password !== $password2) {
		echo "<script>
				alert ('Konformasi Password tidak sesuai');
		 </script>";

		 return false;
	}

	//enkripsi password
	$password = password_hash($password, PASSWORD_DEFAULT);

	//tambahkan user baru ke database
	mysqli_query($conn, "INSERT INTO user VALUES ('','$username','$password')" );

	return mysqli_affected_rows($conn);
}

// function tambahnilai($data){
	
	
// }



?>