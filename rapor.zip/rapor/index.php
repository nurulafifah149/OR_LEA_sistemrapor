<?php 

session_start();

if ( !isset($_SESSION["login"]) ){
	header("location: login.php");
	exit;
}

require 'function.php';
$siswa = query("SELECT * FROM siswa");


//tombol cari ditekan
if ( isset ( $_POST["cari"] ) ) {
	$siswa = cari($_POST["keyword"]);
}


 ?>

<!DOCTYPE html>

<html>
<head>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bulma/0.7.2/css/bulma.min.css">

	<title >Aplikasi Penilaian Siswa</title>


	<style type="text/css">
		body{
			text-align: center;

		}
	.marquee {
      height: 25px;
      width: 1300px;

      overflow: hidden;
      position: relative;
    }

    .marquee div {
      display: block;
      width: 200%;
      height: 30px;

      position: absolute;
      overflow: hidden;

      animation: marquee 10s linear infinite;
    }

    .marquee span {
      float: left;
      width: 50%;
    }

	</style>

</head>
<body bgcolor="beige">
	<div>

	</div>
 <br>	

<div style="text-align: left;
			color: black;
			background-color: cyan;
			text-align: center;
			font-size: 40px;
			font-family: arial;">
	<h1>Penilaian Siswa</h1>
</div>

<br>

<div class="tile is-ancestor">
  <div class="tile is-parent" style="background-color: beige;">
    <article class="tile is-child box">
      <div class="content">
		<article class="panel is-danger">

		  <div class="panel-block">
		  	<form action="" method="post">

		  		<input class="input is-danger" type="text" name="keyword" placeholder="Search" size="40" autocomplete="off">
			      
			      <div class="buttons">

			      	<button style="position: center;" name="cari" class="button is-info is-roundeds" style="margin-right:  20px;"> Cari</button>

			      </div>
			      

		    </form>
		  </div>

		  <a href="tambah.php" class="panel-block is-active" style="color: blue;">
		    Form Data Siswa
		  </a>
		  
		  <a href="tambahnilai.php" class="panel-block" style="color: blue;">
		    Form Nilai Siswa
		  </a>

		  <a href="registrasi.php" class="panel-block" style="color: blue;">
		   	Registrasi
		  </a>

		  <a href="logout.php" class="panel-block" style="color: blue;">
		   	Logout
		  </a>



		  <br><br>

				

		</article>
      </div>
    </article>
  </div>
  <div class="tile is-parent is-8" style="background-color: beige">
    <article class="tile is-child box">
      <p class="title">List Siswa</p>
      
<table class="table is-bordered is-striped is-narrow is-hoverable is-fullwidth" cellpadding="15" cellspacing="1" width="600px">

	<tr>
		<th>No</th>
		<th>Nama</th>
		<th>NISN</th>
		<th>Jenis Kelamin</th>
		<th>Lihat Data</th>

	</tr>

	 
	<?php $i=1; ?>
	<?php foreach ($siswa as $row) :?>

	<tr>

		<td><?= $i; ?></td>
		<td><a href="lihatnilai.php?id_siswa=<?=$row["id_siswa"];?>"><?=$row["nama"];?></a></td>
		<td><?=$row["nisn"];?></td>
		<td><?=$row["jk"];?></td>
		<td><a href="lihat.php?id_siswa=<?=$row["id_siswa"];?>">Lihat</a></td>


	</tr>
	<?php $i++; ?>
	<?php endforeach;?>

</table>

<br><br><br><br><br><br><br><br><br>
    </article>
  </div>
</div>




</body>
</html>