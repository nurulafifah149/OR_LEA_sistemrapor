<?php 

session_start();

if ( !isset ( $_SESSION["login"]) ) {

	header("Location : login.php");
	
	exit;
}

require 'function.php';

$id_siswa= $_GET["id_siswa"];

$data = query("SELECT * FROM siswa WHERE id_siswa='$id_siswa'");
// var_dump($data);

 ?>


<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bulma/0.7.2/css/bulma.min.css">
	<title>Data Siswa</title>
	<style>
 	table,tr,td{
	    background-color: pink;
	    font-family: Comic Sans MS;
	    color: black;
 	}
 	.h{
	    border: 8px groove red;
 	}
 	.posisi{
	    position: absolute;
	    margin-left: auto;
	    margin-right: auto;
	    margin-bottom: auto;
	    margin-top: auto;
	    left: 0;
	    right: 0;
	    top: 130px;
	    bottom: 0;
 	}
	</style>

</head>

<body>
	<h1 style="text-align: center;
			color: black;
			background-color: cyan;
			font-size: 40px;
			font-family: Geneva;">Data Siswa</h1>

<a href="index.php" class="button is-danger">Back</a>


	 <form action="#" style="width: 1000px;" class="posisi">
	 <fieldset class="h"/>
	 <table style="width: 980px;">

	 <?php foreach ($data as $row) :?>
	 <tr>
		 <td rowspan="15" width="250px">
		 <img src="img/<?=$row["gambar"];?>" width="250px" height="250px"/>
		 </td>
	 </tr>

	 <tr>
		 <td><b>NISN</b></td>
		 <td>:</td>
		 <td><?=$row["nisn"];?></td>
	 </tr>

	 <tr>
		 <td><b>Nama</b></td>
		 <td>:</td>
		 <td><?=$row["nama"];?></td>
	 </tr>

	 <tr>
		 <td><b>Panggilan</b></td>
		 <td>:</td>
		 <td><?=$row["nama_panggilan"];?></td>
	 </tr>

	 <tr>
		 <td><b>Jenis Kelamin</b></td>
		 <td>:</td>
		 <td><?=$row["jk"];?></td>
	 </tr>
	  <tr>
		 <td><b>Tempat Lahir</b></td>
		 <td>:</td>
		 <td><?=$row["tempat_lahir"];?></td>
	 </tr>
	  <tr>
		 <td><b>Tanggal Lahir</b></td>
		 <td>:</td>
		 <td><?=$row["tanggal_lahir"];?></td>
	 </tr>
	  <tr>
		 <td><b>Alamat</b></td>
		 <td>:</td>
		 <td><?=$row["alamat"];?></td>

	 </tr>
	
	 <tr>
		 <td style="text-align: right;">
			<a class="button is-link" href="ubahsiswa.php?id_siswa=<?= $row["id_siswa"];?>">ubah</a> 
			<a class="button is-danger" href="hapussiswa.php?id_siswa=<?= $row["id_siswa"];?>" onclick="return confirm('Apakah anda akan menghapus data ini?');">hapus</a>
		 </td>
  	 </tr>
	 <?php endforeach;?>
	 </table>
	 </fieldset>
</body>
</html>



