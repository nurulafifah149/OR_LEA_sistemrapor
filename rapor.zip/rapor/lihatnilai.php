<?php 
session_start();

if ( !isset ( $_SESSION["login"]) ) {

	header("Location : login.php");
	
	exit;
}
require 'function.php';

$id_siswa= $_GET["id_siswa"];

$data = query(" SELECT * FROM nilai JOIN siswa ON nilai.id_siswa = siswa.id_siswa JOIN mapel on nilai.id_mapel=mapel.id_mapel where siswa.id_siswa='$_GET[id_siswa]' ");

 ?>

<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bulma/0.7.2/css/bulma.min.css">
	<title>Data Nilai Siswa</title>
		<style>
 	table,tr,td{
	    background-color: pink;
	    font-family: Comic Sans MS;
	    color: black;
 	}
 	.h{
	    border: 8px groove red;
 	}
 	.posisi{
	    position: absolute;
	    margin-left: auto;
	    margin-right: auto;
	    margin-bottom: auto;
	    margin-top: auto;
	    left: 0;
	    right: 0;
	    top: 130px;
	    bottom: 0;
 	}
	</style>

</head>

<body>
	<h1 style="text-align: center;
			color: black;
			background-color: cyan;
			font-size: 40px;
			font-family: Geneva;">Data Nilai Siswa</h1>
</head>
<body>

<a href="index.php" class="button is-danger">Back</a>

<form action="" method="post">
	<?php foreach ($data as $row) :?>
	 	<br>
	<center>
	<table border="5">

		<tr>
			<th>Nama</th>
			<th><?=$row["nama"];?></th>
		</tr>

		<tr>
			<th>Mata Pelajaran</th>
			<td><?=$row["nama_mapel"];?></td>
		</tr>

		<tr>
			<th>Nilai</th>
			<td><?=$row["nilai"];?></td>

		</tr>

		<tr>
			 
			 	
		</tr>

	</table>
</center>
</form>

 <?php endforeach;?>
</body>
</html>