<?php 
//jalankan sesion di awal program
session_start();

if ( isset($_SESSION["login"]) ) {
	header("Location : index.php");
	exit;
}

require 'function.php';

//cek apakah tombol submit telah ditekan
if (isset($_POST["login"])) {
	
	$username = $_POST["username"];
	$password =$_POST["password"];


	//cek apakah usernamenya ada
	$result = mysqli_query($conn,"SELECT * FROM user WHERE username = '$username'");

	//cek username
	if (mysqli_num_rows($result)==1 ) {

		//cek password
		$row = mysqli_fetch_assoc($result);
		if (password_verify($password, $row["password"])) {

			//set session pd halaman lain
		$_SESSION["login"] = true;

			header("Location: index.php");
			exit;
		}
		
	}

	$error = true;

}

 ?>


 <!DOCTYPE html>
 <html>
 <head>
 	<title>Halaman Login</title>


 </head>
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->	
	<link rel="icon" type="image/png" href="images/icons/favicon.ico"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/Linearicons-Free-v1.0.0/icon-font.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
<!--===============================================================================================-->
 	<style>
		label {
			display: block;
		}


		}
	</style>
<body>
	
	<div class="limiter">
		<div class="container-login100" style="background-image: url('images/img-01.jpg');">
				<div class="wrap-login100 p-t-190 p-b-30">
				<form class="login100-form validate-form" action="" method="post">

					<div class="login100-form-avatar">
						<img src="images/k.jpg" alt="AVATAR">


					</div>

					

					<div class="wrap-input100 validate-input m-b-10" data-validate = "Username is required">
						<input class="input100" type="text" name="username" placeholder="Username" id="username" autocomplete="off">
						<span class="focus-input100"></span>
						<span class="symbol-input100">
							<i class="fa fa-user"></i>
						</span>
					</div>

					<div class="wrap-input100 validate-input m-b-10" data-validate = "Password is required">
						<input class="input100" type="password" name="password" placeholder="Password">
						<span class="focus-input100"></span>
						<span class="symbol-input100">
							<i class="fa fa-lock"></i>
						</span>
					</div>

					<div>
						<?php if (isset($error)) : ?>
			<p style="color: red; font-style: italic; margin-left: 40px; size: 20px;">Username / Password salah</p>
		<?php endif; ?>
					</div>

					<div class="container-login100-form-btn p-t-10">
						<button class="login100-form-btn" name="login">
							Login
						</button>
					</div>

					

				</form>
			</div>
		</div>
	</div>
	
	

	
<!--===============================================================================================-->	
	<script src="vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/bootstrap/js/popper.js"></script>
	<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/select2/select2.min.js"></script>
<!--===============================================================================================-->
	<script src="js/main.js"></script>

</body> 
</html>