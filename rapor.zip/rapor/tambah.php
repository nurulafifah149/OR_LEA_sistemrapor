<?php

session_start();

if ( !isset ( $_SESSION["login"]) ) {

	header("Location : login.php");
	
	exit;
}

require 'function.php';
//cek apakah tombol submit sudah ditekan atau belum
if( isset($_POST["submit"])) {


	//cek apakah data berhasil ditambahkan atau tidak
	if ( tambah($_POST) > 0 ){
		echo "
			<script>
				alert('data berhasil ditambahkan');
				document.location.href='index.php';
			</script>
		";
	}else{
		echo "			
			<script>
				alert('data gagal ditambahkan');
				document.location.href='index.php';
			</script>
		";
	}
}


?>


<!DOCTYPE html>
<html>
<head>
	<title>Tambah data anggota</title>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bulma/0.7.2/css/bulma.min.css">

</head>
<body bgcolor="cornsilk">
	<div    style="text-align: center;
			color: black;
			background-color: cyan;
			font-size: 40px;
			font-family: Geneva;">
	<h1>Tambah Data Anggota</h1>
	</div>
	<a href="index.php" class="button is-link is-outlined">Back</a>
<br>


	<form action="" method="post" enctype="multipart/form-data" style="margin-left: 200px; margin-right: 200px; ">
	<table>

	<div class="field">
  		<label for="nisn" class="label">NISN</label>
  		<div class="control">
    	<input class="input" type="text" name="nisn" id="nisn" required>
 		 </div>
	</div>

	<div class="field">
  		<label for="nama" class="label">Nama</label>
  		<div class="control">
    	<input class="input" type="text" name="nama" id="nama" required>
 		 </div>
	</div>

	<div class="field">
  		<label for="nama_panggilan" class="label">Nama Panggilan</label>
  		<div class="control">
    	<input class="input" type="text" name="nama_panggilan" id="nama_panggilan" required>
 		 </div>
	</div>

	<div class="field">
		<label for="jk" class="label"> Jenis Kelamin</label>
  		<div class="control" >
    	<label class="radio" for="perempuan">
      	<input type="radio" name="jk" value="P" required>
      	Perempuan
    	</label >
    	<label class="radio" for="lakilaki">
      	<input type="radio" id="lakilaki" name="jk" value="L" required>
      	Laki-laki
    	</label>
  		</div>
	</div>

	
	<div class="field">
  		<label for="tempat_lahir" class="label">Tempat Lahir</label>
  		<div class="control">
    	<input class="input" type="text" name="tempat_lahir" id="tempat_lahir" required>
 		 </div>
	</div>

	<div class="field">
  		<label for="tanggal_lahir" class="label">Tanggal Lahir</label>
  		<div class="control">
    	<input class="input" type="date" name="tanggal_lahir" id="tanggal_lahir" required>
 		 </div>
	</div>
	
	<div class="field">
  		<label class="label">Alamat</label>
  		<div class="control">
    	<input class="input" type="text" name="alamat" id="alamat" required>
 		</div>
	</div>

			<label for="gambar" class="label">Gambar</label>
		<input type="file" name="gambar" id="gambar" required>

				
		<br><br>

	<div class="field is-grouped">
  		<div class="control">
    		<button class="button is-link" type="submit" name="submit" style="margin-left: 800px;">Tambah Data</button>
  		</div>
  	</div>

<br><br>

	</form>



</body>
</html>