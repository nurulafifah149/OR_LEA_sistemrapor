<?php

session_start();

if ( !isset ( $_SESSION["login"]) ) {

	header("Location : login.php");
	
	exit;
}

require 'function.php';
//cek apakah tombol submit sudah ditekan atau belum
if( isset($_POST["submit"])) {


	//cek apakah data berhasil ditambahkan atau tidak
	if ( tambah($_POST) > 0 ){
		echo "
			<script>
				alert('data berhasil ditambahkan');
				document.location.href='index.php';
			</script>
		";
	}else{
		echo "			
			<script>
				alert('data gagal ditambahkan');
				document.location.href='index.php';
			</script>
		";
	}
}


?>


<!DOCTYPE html>
<html>
<head>
	<title>Tambah Nilai Siswa</title>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bulma/0.7.2/css/bulma.min.css">

</head>
<body bgcolor="cornsilk">
	<div    style="text-align: center;
			color: black;
			background-color: cyan;
			font-size: 40px;
			font-family: Geneva;">
	<h1>Tambah Nilai Siswa</h1>
	</div>
	<a href="index.php" class="button is-link is-outlined">Back</a>
<br>


	<form action="" method="post" enctype="multipart/form-data" style="margin-left: 200px; margin-right: 200px; ">
		

	<div class="field" style="width: 1000px;">
  		<label class="label">Nama Siswa</label>
  		<div class="control">
    	<select>Pilih
    	<?php $ambil = $conn->query("SELECT * FROM siswa") ?>
		<?php while($pisah=$ambil->fetch_assoc()) {?>
    		<option value="<?php echo $pisah['id_siswa']; ?>"><?php echo $pisah['nama']; ?></option>
    		<?php } ?>

    	</select>
 		 </div>
	</div>

		<br>	

	<div class="field" style="width: 1000px;">
  		<label class="label">Mata Pelajaran</label><br>
  		<div class="control">
    	<label>Bahasa Indonesia</label><br>
    	<input type="number" name="nilai" id="nilai" >
 		 </div>
	</div>
		
		<br>

	<div class="field" style="width: 1000px;">
  		<div class="control">
    	<label>Matematika</label><br>
    	<input type="number" name="nilai" id="nilai" >
 		 </div>
	</div>
		
		<br>

		<div class="field" style="width: 1000px;">
  		<div class="control">
    	<label>IPA</label><br>
    	<input type="number" name="nilai" id="nilai" >
 		 </div>
	</div>
		
		<br>

		<div class="field" style="width: 1000px;">
  		<div class="control">
    	<label>IPS</label><br>
    	<input type="number" name="nilai" id="nilai" >
 		 </div>
	</div>
		
		<br>

		<div class="field" style="width: 1000px;">
  		<div class="control">
    	<label>Bahasa Inggris</label><br>
    	<input type="number" name="nilai" id="nilai" >
 		 </div>
	</div>
		
		<br>

		<div class="field" style="width: 1000px;">
  		<div class="control">
    	<label>PKN</label><br>
    	<input type="number" name="nilai" id="nilai" >
 		 </div>
	</div>
		
		<br>

		<div class="field" style="width: 1000px;">
  		<div class="control">
    	<label>Agama</label><br>
    	<input type="number" name="nilai" id="nilai" >
 		 </div>
	</div>
		
		<br>

		<div class="field" style="width: 1000px;">
  		<div class="control">
    	<label>Seni Budaya</label><br>
    	<input type="number" name="nilai" id="nilai" >
 		 </div>
	</div>
		
<br><br>

	</form>

	<div class="field is-grouped">
  		<div class="control">
    		<button class="button is-warning" type="submit" name="submit" style="margin-left: 800px;">Tambah Data</button>
  		</div>
  	</div>


<!-- $conn -> query ("INSERT INTO nilai VALUES 
			('', '$_POST[id_siswa]', '$_POST[id_mapel]', '$_POST[nilai]'), 
			('', '$_POST[id_siswa]', '$_POST[id_mapel]', '$_POST[nilai]'),
			('', '$_POST[id_siswa]', '$_POST[id_mapel]', '$_POST[nilai]'),
			('', '$_POST[id_siswa]', '$_POST[id_mapel]', '$_POST[nilai]'),
			('', '$_POST[id_siswa]', '$_POST[id_mapel]', '$_POST[nilai]'),
			('', '$_POST[id_siswa]', '$_POST[id_mapel]', '$_POST[nilai]'),
			('', '$_POST[id_siswa]', '$_POST[id_mapel]', '$_POST[nilai]'),
			('', '$_POST[id_siswa]', '$_POST[id_mapel]', '$_POST[nilai]'),
			 "); -->


</body>
</html>

<?php 
if (isset($_POST["submit"])) {


	$conn->query("INSERT INTO nilai (id_siswa, id_mapel, nilai)
			VALUES
			('$_POST[id_siswa]','1','$_POST[nilai]'),
			('$_POST[id_siswa]','2','$_POST[nilai]'),
			('$_POST[id_siswa]','3','$_POST[nilai]'),
			('$_POST[id_siswa]','4','$_POST[nilai]'),
			('$_POST[id_siswa]','5','$_POST[nilai]'),
			('$_POST[id_siswa]','6','$_POST[nilai]'),
			('$_POST[id_siswa]','7','$_POST[nilai]'),
			('$_POST[id_siswa]','8','$_POST[nilai]')

			");




	$ambil=$conn->query("SELECT*FROM nilai");
	while ($tampil=$ambil->fetch_assoc()) {
		$id=$tampil['id_nilai'];

	}
	//redirect
	echo "<div class='alert alert-info'>Login Aman</div>";
    echo "<meta http-equiv='refresh' content='index.php'>";

		}

?>











		





 