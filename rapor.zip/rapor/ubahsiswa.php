<?php

session_start();

if ( !isset($_SESSION["login"]) ){

	header("location: login.php");
	
	exit;
}

require 'function.php';

//ambil data di URL
$id_siswa= $_GET["id_siswa"];
//query data mahasiswa berdasarkan id
$siswa = query("SELECT * FROM siswa WHERE id_siswa='$id_siswa'")[0];

//cek apakah tombol submit sudah ditekan atau belum
if( isset($_POST["submit"])) {

	//cek apakah data berhasil diubah atau tidak
	if (ubahsiswa($_POST)>0){
		echo "
			<script>
				alert('data berhasil diubah');
				document.location.href='index.php';
			</script>
		";
	}else{
		echo "			
			<script>
				alert('data gagal diubah');,
				document.location.href='index.php';
			</script>
		";
	}
}


?>


<!DOCTYPE html>
<html>
<head>
	<title>Edit Data Siswa</title>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bulma/0.7.2/css/bulma.min.css">
</head>
<body>
	<div style="text-align: center;
			color: black;
			background-color: coral;
			font-size: 30px;
			font-family: Geneva;">

	<h1>Edit Data Siswa</h1>
	</div>
<br>


	<form action="" method="post" enctype="multipart/form-data" style="margin-left: 100px;">
		<input type="hidden" name="id_siswa" value="<?=$siswa["id_siswa"];?>">
		<input type="hidden" name="gambarLama" value="<?=$siswa["gambar"];?>">

	<div class="field" style="width: 1000px;">
  		<label class="label">NISN</label>
  		<div class="control">
    	<input class="input" type="text" name="nisn" id="nisn" 
				required
				value="<?= $siswa["nisn"];?>">
 		 </div>
	</div>

	<div class="field" style="width: 1000px;">
  		<label class="label">Nama</label>
  		<div class="control">
    	<input class="input" type="text" name="nama" id="nama" 
				required
				value="<?= $siswa["nama"];?>">
 		</div>
	</div>

	<div class="field" style="width: 1000px;">
  		<label class="label">Panggilan</label>
  		<div class="control">
    	<input class="input" type="text" name="nama_panggilan" id="nama_panggilan" 
				required
				value="<?= $siswa["nama_panggilan"];?>">
 		</div>
	</div>
	
	<div class="field">
  		<div class="control">
  		<label for="jk" class="label"> Jenis Kelamin</label>
    	<label class="radio" for="perempuan">
      	<input type="radio" name="jk" value="P" required >
      	Perempuan
    	</label >
    	<label class="radio" for="lakilaki">
      	<input type="radio" id="lakilaki" name="jk" value="L" required>
      	Laki-laki
    	</label>
  		</div>
	</div>

	<div class="field" style="width: 1000px;">
  		<label class="label">Tempat Lahir</label>
  		<div class="control">
    	<input class="input" type="text" name="tempat_lahir" id="tempat_lahir" 
				required
				value="<?= $siswa["tempat_lahir"];?>">
 		</div>
	</div>

	<div class="field" style="width: 1000px;">
  		<label class="label">Tanggal Lahir</label>
  		<div class="control">
    	<input class="input" type="date" name="tanggal_lahir" id="tanggal_lahir" 
				required
				value="<?= $siswa["tanggal_lahir"];?>">
 		</div>
	</div>

	<div class="field" style="width: 1000px;">
  		<label class="label">Alamat</label>
  		<div class="control">
    	<input class="input" type="text" name="alamat" id="alamat" 
				required
				value="<?= $siswa["alamat"];?>">
 		 </div>
	</div>

				<input type="file" name="gambar" id="gambar" >

				
		<br><br>

	<div class="field is-grouped">
  		<div class="control">
    		<button class="button is-link" type="submit" name="submit">Ubah Data</button>
  		</div>
  	</div>

<br><br>

	</form>



</body>
</html>